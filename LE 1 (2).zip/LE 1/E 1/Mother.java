class Mother
{
    void show(){
        System.out.println("Show of Mother class.  ");
    }
}