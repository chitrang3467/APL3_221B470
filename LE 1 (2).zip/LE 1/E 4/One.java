public class One {
    One(int x) {
        System.out.println("Constructor of One, value of x: " + x);
    }
}