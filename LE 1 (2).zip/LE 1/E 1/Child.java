class Child extends Mother
{
    
}