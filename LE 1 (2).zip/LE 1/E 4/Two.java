public class Two extends One {
    
}